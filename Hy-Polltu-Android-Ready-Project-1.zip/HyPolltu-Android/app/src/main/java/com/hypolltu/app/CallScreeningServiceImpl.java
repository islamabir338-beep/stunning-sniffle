package com.hypolltu.app;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.telecom.Call;
import android.telecom.CallScreeningService;

public class CallScreeningServiceImpl extends CallScreeningService {
    public static final String CHANNEL_ID = "hypolltu_calls";

    @Override
    public void onScreenCall(Call.Details details) {
        if (details == null || details.getCallDirection() != Call.Details.DIRECTION_INCOMING) return;

        // This first version never answers, rejects, records, or forwards calls.
        CallResponse response = new CallResponse.Builder()
            .setDisallowCall(false)
            .setRejectCall(false)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build();
        respondToCall(details, response);

        Uri handle = details.getHandle();
        String number = handle == null ? "অজানা নম্বর" : handle.getSchemeSpecificPart();
        if (number == null || number.trim().isEmpty()) number = "অজানা নম্বর";

        NotificationManager manager = getSystemService(NotificationManager.class);
        if (manager == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && manager.getNotificationChannel(CHANNEL_ID) == null) {
            manager.createNotificationChannel(new NotificationChannel(
                CHANNEL_ID, "Incoming call alerts", NotificationManager.IMPORTANCE_HIGH));
        }

        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 1, open,
            PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));

        Notification.Builder builder = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
            ? new Notification.Builder(this, CHANNEL_ID)
            : new Notification.Builder(this);
        Notification notification = builder
            .setSmallIcon(android.R.drawable.sym_call_incoming)
            .setContentTitle("Hy Polltu: ইনকামিং কল")
            .setContentText("কল আসছে: " + number)
            .setContentIntent(pendingIntent)
            .setAutoCancel(true)
            .setCategory(Notification.CATEGORY_CALL)
            .build();
        manager.notify((int) (System.currentTimeMillis() & 0x7fffffff), notification);
    }
}
