HY POLLTU — ANDROID PROJECT

এই প্রজেক্টে যা আছে
- আগের Premium Dark Hy Polltu HTML অ্যাপ Android WebView-তে চলে
- Incoming call screening service
- কল এলে নম্বরসহ notification দেখায়
- Android 10+ এ Call Screening role নেওয়ার অনুরোধ করে
- Android 13+ এ notification permission চায়
- অপ্রয়োজনীয় contacts/SMS/microphone permissions নেই

গুরুত্বপূর্ণ সীমাবদ্ধতা
- বর্তমান HTML এখনো Demo Mode; বাস্তব AI উত্তর পেতে নিরাপদ backend/API deploy করতে হবে।
- বর্তমান কল ফিচার কল শনাক্ত করে notification দেয় মাত্র। এটি কল ধরে না, কথা বলে না,
  রেকর্ড করে না, নিজে থেকে reject করে না বা অন্য কারও কাছে পাঠায় না।
- Android-এর নীতিমালা ও ডিভাইস অনুযায়ী Call Screening role অনুমোদন প্রয়োজন।
- Android 7–9 এ সেটিংস থেকে Caller ID/Spam বা Call Screening app হিসেবে বেছে নিতে হতে পারে।

APK তৈরি (AndroidIDE)
1. ZIP extract করুন।
2. AndroidIDE-তে HyPolltu-Android ফোল্ডারটি Open Project করুন।
3. Gradle sync শেষ হলে Build > Assemble Debug করুন।
4. APK: app/build/outputs/apk/debug/app-debug.apk

GitHub Actions দিয়েও Build APK workflow চালানো যায়।
API key কখনো HTML বা APK-তে রাখবেন না।
